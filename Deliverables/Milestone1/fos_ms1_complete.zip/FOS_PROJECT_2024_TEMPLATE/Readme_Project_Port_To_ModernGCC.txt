https://gcc.gnu.org/gcc-5/porting_to.html

"Adding the inline doesn't fix it. You also have to add static,"
http://stackoverflow.com/questions/13147170/attribute-always-inline-failing

https://gcc.gnu.org/onlinedocs/gcc/Inline.html